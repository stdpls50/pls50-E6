/* 8.E. PLS 50 (2016-17)                          *
** GRIGORIADOU MARIA                              *
** THEMA 3o: YLOPOIHSH PARALLAGHS PAIXNIDIOU SET  */



//Arxeia epikefalidas
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <conio.h>

#define N 3

//Orizw ta prwtotypa twn sunarthsewn
void create_cards(void); //dhmiourgia twn kartwn
void create_players(struct players_info* ); //dhmiourgia paiktwn
void getnextcard(int*); //epilogh 12 tuxaiwn kartwn
int check_cards (int,int,int); //elegxos epilegmenwn kartwn apo ton paikth
void print_generated_cards(int*); //ektupwsh twn tuxaiwn 12 kartwn
int select_cards(int *); //o paikths epilegei 3 kartes
char players(struct players_info*,int*,int);//epilogh paiktwn kai ektupwsh twn plhroforiwn
int change_score(struct players_info*,char,int); //allagh tou score
void print_players_info(struct players_info* ); // ektupwsh stoixeiwn paiktwn

//Orizw domh me ta stoixeia twn paiktwn
struct players_info{
    char name[17];
    char id;
    int score;
};

//orizw domh me ta xarakthristika twn kartwn
struct card{
    char color;
    char shape;
    int num;
    char texture;
};

struct card pin[81]; //pinakas twn kartwn

//Main program
int main()
{
    struct players_info store[N]; //pinakas N thesewn gia paiktes
    srand(time(NULL));
    char cur_player; //o trexwn paikths
    int temp[12],x,s=-1;

    create_players(store);
    create_cards();
    cur_player=players(store,temp,1); //klhsh ths sunarthshs gia thn epilogh id paikth

    while (cur_player!='0')
    {
        printf("\n\n*Selected player ID:%c\n",cur_player);
        x=select_cards(temp); //klhsh sunarthshs gia thn epilogh 3 kartwn

        if (x==1)
        {
            printf("\nSet");
            s=change_score(store,cur_player,x); //klhsh sunarthshs gia thn allagh tou score an uparxei set
            if(s!=-1) //an exoume nikiti
                break;
        }
        if (x==-1)
        {
            printf("\n Not a Set.");
            s=change_score(store,cur_player,x); //klhsh sunarthshs gia thn allagh tou score an den uparxei set
        }
        cur_player=players(store,temp,x); //klhsh sunarthshs gia thn epilogh id paikth

    }
    print_players_info(store); //ektupwsh stoixeiwn olwn twn paiktwn
    if (s!=-1)
        printf("/nO nikitis einai %s",store[s].name); //an exoume nikiti,emfanizei to onoma tou
    printf("\nGame Over!!");
    return 0;
}


void create_cards(void) //dhmiourgia kartwn
{
    char col[]="rgb",sha[]="ctr",text[]="bhe";
    //col=xrwma,sha=sxhma,text=ufh
    int nu[]={1,2,3},i=0,j, c,n=0,t=0,s;
    for (c=0;c<3;c++) //metrhths gia thn allagh xrwmatos
    {
        s=0; //metrhths gia allagh sxhmatos
        for (j=0;j<27;j++)
        {
            if (j%3==0)
            {
                t=0; //metrhths gia thn allagh ufhs
                if (j!=0)
                    n++;//metrhths allaghs ari8mou
            }
            if (j%9==0)
            {
                n=0;
                if (j!=0)
                    s++;
            }
            pin[i].color=col[c];
            pin[i].shape=sha[s];
            pin[i].num=nu[n];
            pin[i].texture=text[t++];
            i++;
        }
    }

}



void create_players(struct players_info* temp) //eisagwgh stoixeiwn twn paiktwn
{
    strcpy(temp[0].name,"Marina Andreou");
    strcpy(temp[1].name,"Kostas Grammenos");
    strcpy(temp[2].name, "Maria Perdika");
    temp[0].id='a';
    temp[1].id='g';
    temp[2].id='p';
    temp[0].score=0;
    temp[1].score=0;
    temp[2].score=0;

}



void print_generated_cards(int *temp)
{
    int i;
    printf("\nRandom Cards");
    for(i=0;i<12;i++)
    {
        if (i%4==0)
            putchar('\n');
        printf("[%c,%c,%d,%c]",pin[temp[i]].color,pin[temp[i]].shape,pin[temp[i]].num,pin[temp[i]].texture);
    }
}

char players(struct players_info* info,int* temp, int x)
{
    char cur_player;
    do
    {
        if (x!=-1) //an to x pou mas epistrefei h select_card kanei SET dhmiourgoume 12 nees kartes
        {
            getnextcard(temp);
        }
        print_generated_cards(temp);//emfanisi twn idiwn kartwn an den exoume set,an exoume emfanizontai autes pou dhmiourghsame parapanw
        print_players_info(info);
        printf("\n\nSelect player ID:");
        cur_player=getche();
    }while(cur_player!='a'&& cur_player!='g' && cur_player!='p' && cur_player!='0');//perimenei id paikth h 0

    return cur_player;

}

int select_cards(int* random) //painei san orisma ton 128esio pinaka me tis tuxaies kartes
{
    int mat1[3],i=1,s,x=-1,y=-1;
    char temp[5];
    printf("\nSelect Card. (x=row,y=column)\n");
    printf("Accepted Values for x[0-2]\n");
    printf("Accepted Values for y[0-3]\n\n");
    do
    {
        do
        {
            printf("(x,y) for card %d.\n",i);
            printf("X:");
            gets(temp);
            x=atoi(temp);
            printf("Y:");
            gets(temp);
            y=atoi(temp);
        }while (x<0 || x>2 || y<0 || y>3); //oria gia tis times twn x kai y
        mat1[i-1]=x*4+y; //vriskoume ki apo8ikeuoume th thesh th skartas pou epele3e se enan proswrino pinaka
        i++;
    }while(i<=3);
    s=check_cards(random[mat1[0]],random[mat1[1]],random[mat1[2]]); //kaloume th sunarthsh me orisma tis epilegmenes kartes tou paikth
    return s;

}


void getnextcard(int* card) //epilogh 12 monadikwn kartwn
{
    int i,j,uniqueflag,random,k=81;
    for(i=0;i<12;i++)
    {
        do
        {
            uniqueflag=1;
            if(i>0&&i%4==0)
                k-=27;
            random=rand()%k;
            for (j=0;j<1 && uniqueflag==1;j++)
            {//elegxoume gia th monadikothta stis kartes pou epilegontai na mhn uparxoun diples
                if (card[j]==random)
                {
                    uniqueflag=0;
                }
            }

        }while (uniqueflag!=1);
        card[i]=random;//apo8hkeush ston pinaka mas
    }

}

int check_cards(int c1,int c2,int c3)//san orisma dexetai tis 3 kartes pou exoun epilex8ei apo ton paikth
{
    //to xrwma einai diaforetiko se oles tis kartes
    //ta upoloipa xarakthristika einai pantou ta idia
    if (pin[c1].color!=pin[c2].color && pin[c2].color!=pin[c3].color && pin[c3].color!=pin[c1].color)
    {
        if (pin[c1].shape==pin[c2].shape && pin[c2].shape==pin[c3].shape && pin[c3].shape==pin[c1].shape)
        if (pin[c1].num==pin[c2].num && pin[c2].num==pin[c3].num && pin[c3].num==pin[c1].num)
        if (pin[c1].texture==pin[c2].texture && pin[c2].texture==pin[c3].texture && pin[c3].texture==pin[c1].texture)
        return 1;

    }
    //o arithmos einai se oles tis kartes diaforetikos
    //ta upoloipa xarakthristika einai idia
    if (pin[c1].num!=pin[c2].num && pin[c2].num!=pin[c3].num && pin[c3].num!=pin[c1].num)
    {
        if (pin[c1].color==pin[c2].color && pin[c2].color==pin[c3].color && pin[c3].color==pin[c1].color)
        if (pin[c1].shape==pin[c2].shape && pin[c2].shape==pin[c3].shape && pin[c3].shape==pin[c1].shape)
        if (pin[c1].texture==pin[c2].texture && pin[c2].texture==pin[c3].texture && pin[c3].texture==pin[c1].texture)
        return 1;

    }
    //o arithmos einai se oles tis kartes idios
    //t aupoloipa xarakthristika einai diaforetika
    if (pin[c1].num==pin[c2].num && pin[c2].num==pin[c3].num && pin[c3].num==pin[c1].num)
    {
        if (pin[c1].color!=pin[c2].color && pin[c2].color!=pin[c3].color && pin[c3].color!=pin[c1].color)
        if (pin[c1].shape!=pin[c2].shape && pin[c2].shape!=pin[c3].shape && pin[c3].shape!=pin[c1].shape)
        if (pin[c1].texture!=pin[c2].texture && pin[c2].texture!=pin[c3].texture && pin[c3].texture!=pin[c1].texture)
        return 1;
    }
    return -1;

}

int change_score(struct players_info* temp,char id, int x)
{
    int i;
    if (x==1) //an exoume set
    {
        for (i=0;i<N;i++) //psaxnoume tous paiktes sumfwna me to id tou trexontos paikth
        {
            if (temp[i].id==id)
            {
                temp[i].score+=2;
                if (temp[i].score>=10) //an to score tou einai >=10, tote epistrefoume
                                    //th thesh tou ston pinaka store gia na exoume ta stoixeia tou nikiti
                    return i;
            }
            return -1;
        }
    }
    if (x==-1) //an den exoume set
        for(i=0;i<N;i++)
    {
        if (temp[i].id==id && temp[i].score!=0)
        {
            temp[i].score-=1;
            return -1;
        }
    }
    return -1;
}


void print_players_info(struct players_info* info)
{
    int i;
    printf("\n\n\n|Players|");
    for (i=0;i<N;i++)
    {
        printf("\nPlayer_%d:%s ID:%c Score:%d", i+1,info[i].name,info[i].id,info[i].score);
    }
}




