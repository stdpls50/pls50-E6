/* 8.E. PLS50 (2016-17) GRAPTH ERGASIA E1   *
** GRIGORIADOU MARIA                        *
** THEMA 1: APLH ARI8MOMHXANH               */


/*Header files*/
#include <stdio.h>

/*Main Program*/

int main(void)
{
    float num1,num2; //oi metavlites num1 kai num2 8a xrhsimopoih8oun gia thn eisodo arithmwn apo to xrhsth
    char pra3i;      //h metavliti pra3i 8a xrhsimopoih8ei gia thn eisodo ths p3a3hs apo to xrhsth pou epi8umei o idios na ektelesei

    /*Emfanish mhnumatos sthn o8onh tou xrhsth kai diavasma twn epilogwn (ari8mwn-pra3hs) pou kanei */

    printf("Dwse arithmo pra3i arithmo!\n");
    scanf("%f %c %f",&num1,&pra3i,&num2);

    /*Emfanish mhnumatos la8ous pros to xrhsth kai diavasma twn epilogwn tou ek neou. *
    ** To mhnuma epanalvanetai ews otou ginei swsth kataxwrish.                       */

    while(pra3i!='+' && pra3i!='-' && pra3i!='*' && pra3i!='/')
    {
        printf("Lathos pra3i!\n");
        printf("Dwse arithmo pra3i arithmo!\n");
        scanf("%f %c %f",&num1,&pra3i,&num2);

    }

    /* Ypologismos ki emfanish tou apotelesmatos sthn o8onh, sumfwna me tis epiloges (ari8moi-pra3i) tou xrhsth  *
    ** Gia thn emfanisi tou apotelsmatos exei ginei h epilogh 2 dekadikwn psifiwn,                               *
    ** wste na tairiazei me to pardeigma ths ekfwnhshs ths askhshs.                                              */

    if (pra3i=='+')                             //periptwsh epiloghs pros8eshs
       printf("Apotelesma=%.2f\n", num1+num2);
    else if (pra3i=='-')                        //periptwsh epiloghs afaireshs
        printf("Apotelesma=%.2f\n",num1-num2);
    else if (pra3i=='*')                        //periptwsh epiloghs pollaplasiasmou
        printf("Apotelesma=%.2f\n",num1*num2);
    else if (pra3i=='/')                        // periptwsh epiloghs diaireshs
    {
        if (num2==0)
            printf("Den orizetai diairesh me to mhden!\n"); //emfanish mhnumatos la8ous an o xrhsths exei epile3ei diaresh me to mhden
        else
            printf("Apotelesma=%.2f\n",num1/num2);
    }
    return 0;
}
