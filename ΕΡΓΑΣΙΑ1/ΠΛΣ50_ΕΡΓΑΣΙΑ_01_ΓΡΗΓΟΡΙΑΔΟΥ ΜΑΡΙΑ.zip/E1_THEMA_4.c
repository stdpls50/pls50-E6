/* 8.E. PLS50 (2016-17) GRAPTH ERGASIA E1 *
** GRIGORIADOU MARIA                      *
** THEMA 4: SUSTHMA KATAGRAFHS THESEWN    */

/*Header Files*/
#include <stdio.h>
#include <stdlib.h> //Apaiteitai gia th xrhsh ths exit()


/*Main Program*/
int main()
{
    int maxtheseis[53]={0},theseislewf,i,choice,cnt=0,kenestheseis[theseislewf],numthesis;
    char pinakida[8]; //o pinakas pinakida exei 8 theseis, gt upologizoume kai ton xarakthra '\0'

    FILE *infile;     //Dhlwnetai to arxeio anagnwshs
    infile=fopen("bus.txt", "r"); //Anoigma tou arxeiou bus gia anagnwsh


    if (infile==NULL)
    {
        printf("Error!File cannot be opened!\n"); //An de vre8ei to arxeio gia anagnwsh, ektypwnetai mhnuma lathous
        exit(2);                                  //kai to programma termatizetai
    }

    /*Diavazetai apo to arxeio bus h pinakida kai kataxwrizetai se pinaka me onoma pinakida*/
    fscanf(infile, "%s", pinakida);
    printf("%s",pinakida);

    /*Diavazetai apo to arxeio bus o arithmos 8esewn tou lewforeiou kai kataxwrizetai se metavliti*/
    fscanf(infile,"%d",&theseislewf);
    printf(" %d\n\n",theseislewf);
    fclose(infile); //kleinei to arxeio bus , afou pleon de xreiazetai


    /*Ginetai elegxos gia to ean o arithmos twn 8esewn einai entos oriwn *
    **ki an oi 8eseis sumvadizoun me thn katanomh 4xN+5*/
    if (theseislewf<0 || (theseislewf>53 || (theseislewf-5)%4!=0))
    {
        printf("Error!Provlima ston arithmo 8esewn tou lewforeiou!\n");
        return 0;
    }


   do
   {
        /*Emfanish tou menu epilogwn sthn o8onh tou xrhsth*/
        printf("Epele3e:\n");
        printf("1:Emfanisi tou sunolikou plh8ous kenwn thesewn kai twn ari8mwn.\n");
        printf("2:Krathsh 8eshs me sugkekrimeno ari8mo.\n");
        printf("3:Euresh apo to programma kai krathsh ths prwths kenhs 8eshs pou vriksetai se para8uro.\n");
        printf("4:Akurwsh krathshs 8eshs me sugkekrimeno ari8mo.\n");
        printf("5:Anazhthsh an einai krathmenh 8esh me sugkerimeno ari8mo.\n");
        printf("6:Emfanish listas krathmenwn 8esewn ta3inomhmenhs kata ari8mo 8eshs.\n");
        printf("7:Emfanish ths pinakidas kukloforias kai tou diagrammatos tou lewforeiou.\n");
        printf("8:Apo8hkeush ths pinakidas kukloforias kai tou diagrammatos tou lewforeiou se arxeio me onoma layout.txt.\n");
        printf("0:Termatismos programmatos.\n\n");
        scanf("%d",&choice); //diavasma ths epiloghs tou xrhsth
        if (choice==0) //an epile3ei 0 , dhl. e3odo, to programma termatizei
            exit(1);

        if(choice==1)
        {
            for(i=0;i<theseislewf;i++)
            {
                if (maxtheseis[i]==0) //efoson sth 8esh einai kataxwrimeno to 0, h 8esh einai dia8esimi
                {
                    cnt++; //h metavliti cnt metraei to plithos twn kenwn 8esewn
                    kenestheseis[cnt-1]=cnt; //o pinakas kenestheseis krataei tous arithmous twn kenwn thesewn
                }
            }
            printf("%d\n",cnt);
            for (i=0;i<cnt;i++)
            {
                printf("%d ",kenestheseis[i]);
            }
            printf("\n");
        }
        else if (choice==2)
        {
            printf("Dwse arithmo thesis apo 1 ews %d:\n",theseislewf);
            scanf("%d",&numthesis);

            while((numthesis<0)||(numthesis>theseislewf)) //ginetai elegxos gia to ean o ari8mos ths 8eshs einai entos oriwn
            {
                printf("Dwse arithmo 8eshs (1 ews %d):\n",theseislewf);
                scanf("%d",&numthesis);
            }
            if (maxtheseis[numthesis-1]==1) //an h 8esh einai hdh krathmenh, emfanizetai to antistoixo mhnuma
            {
                printf("H thesh %d einai hdh krathmenh!\n",numthesis);
            }
            else //an h 8esh einai kenh
            {
                maxtheseis[numthesis-1]=1; //pleon h 8esh dhlwnetai ws krathmenh
                printf("H thesi %d molis krath8hke!\n",numthesis); //ki ektupwnetai to katallhlo mhnuma

            }

        }
        else if (choice==3)
        {

        /*.............................DEN APANTH8HKE.............................*/

        }
        else if (choice==4)
        {
            printf("Dwse arithmo thesis gia akurwsh (1 ews %d):\n",theseislewf);
            scanf("%d",&numthesis);

            if (numthesis<0 || numthesis>theseislewf) //elegxos gia to ean o ari8mos 8eshs einai entos oriwn
            {
                printf("Dwse arithmo thesis gia akurwsh (1ews %d):\n",theseislewf);
                scanf("%d",&numthesis);
            }
            if (maxtheseis[numthesis-1]==0) //elegxos gia to ean h 8esh einai dia8esimi
            {
                printf("H thesi den einai krathmenh!\n");

            }
            else //an h 8esh einai hdh krathmenh , tote h 8esh pleon akurwnetai kai pairnei timh 0
            {
                maxtheseis[numthesis-1]=0;
                printf("H thesh %d akurwthike!!\n",numthesis);
            }

        }
        else if (choice==5)
        {
            printf("Dwse arithmo thesis (1ews %d):\n",theseislewf); //zhteitai apo to xrhsth sugkerimenos ari8mos 8eshs
            scanf("%d",&numthesis);
            if (numthesis<0 || numthesis>theseislewf) //elegxos gia to ean o ari8mos 8eshs einai entos oriwn
            {
                printf("Dwse arithmo thesis (1ews %d):\n",theseislewf);
                scanf("%d",&numthesis);
            }
            if (maxtheseis[numthesis-1]==1)
                printf("H thesi %d einai krathmenh!\n",numthesis);
            else
                printf("H thesi %d einai diathesimh!\n",numthesis);

        }
        else if (choice==6)
        {
            printf("Emfanish listas krathmenwn thesewn ta3inomhmenhs kata arithmo 8eshs:\n");
            for (i=0;i<theseislewf;i++)
            {
                if (maxtheseis[i]==1)
                    printf("%d ",i+1);
            }

        }
        else if (choice==7)
        {
            /*Ektupwsh ths pinakidas kai twn 8esewn tou lewforeiou */
            printf("%s",pinakida);
            printf(" %d\n",theseislewf);

            for (i=0;i<theseislewf-5;i++) //elegxw prwta gia oles tis 8eseis plhn ths galarias
            {
                if (i%4==0) //akrivws me to 4 diaireitai mono h teleutaia 8esh ka8e seiras
                    printf("\n");
                else if (i%2==0) //h 2h thesh ka8e seiras diaireitai me to 2,mono
                    printf(" ");
                if (maxtheseis[i]==1) //ean h 8esh exei timh 1, einai krathmenh kai tupwnetai to *
                    printf("*");
                else //alliws h 8esh einai kenh kai tupwnetai _
                    printf("_");
            }
            printf("\n");

            for (i=theseislewf-5;i<theseislewf;i++) //sth sunexeia elegxw tis 5 8eseis ths galarias
            {
                if (maxtheseis[i]==1)
                    printf("*");
                else
                    printf("_");
            }
            printf("\n");
        }
        else if (choice==8)
            /*....................DEN APANTH8HKE....................*/



        printf("\n______________________________________________\n");
   }while(1);

   return 0;
}
