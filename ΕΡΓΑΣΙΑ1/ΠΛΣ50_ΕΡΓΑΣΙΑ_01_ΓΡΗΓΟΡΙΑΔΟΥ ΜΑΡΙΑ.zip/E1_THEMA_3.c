/* 8.E. PLS50 (2016-17) GRAPTI ERGASIA E1   *
** GRIGORIADOU MARIA                        *
** THEMA 3: DUADIKH ANAPARASTASH ARI8MOU    */

/*Header files*/
#include <stdio.h>

/*Main Program*/
int main(void)
{
    int akeraios,ypoloipo;
    const int i=2;  //orizetai sta8era i gia tous upologismous

    /*Zhteitai apo ton xrhsth enas 8etikos akeraios*/
    printf("Dwse enan thetiko akeraio ari8mo:\n");
    scanf("%d",&akeraios);

    /*Se periptwsh pou o xrhsths dwsei arnhtiko,emfanizei mhnuma la8ous *
    **kai zhtaei neo ari8mo                                             */
    while(akeraios<0)
    {
        printf("Edwses arnhtiko akeraio ari8mo.\n");
        printf("Dwse thetiko akeraio ari8mo!!!\n");
        scanf("%d",&akeraios);
    }


    /* Sth sunexeia upologizetai to akeraio upoloipo tou do8entos akeraiou me to 2.                 *
    ** An einai 1 tupwnei sthn o8onh 1, an einai 0 emfanizei 0.                                     *
    ** Na shmeiwsoume pws h tupwsh tou upoloipou ginetai ekeinh th stigmh akrivws pou upologizetai  *
    ** wste telika, na tupwnetai sthn o8onh h antistrofh duadikh anaparastash autou.                *
    ** Telos, upologizetai to akeraio phliko ths diaireshs tou ari8mou me to 2, to opoio 8a apotelei*
    ** ton neo trexonta ari8mo. H diadikasia sunexizetai mexri to phliko na ginei 0.                */

    while (akeraios>0)
    {
        ypoloipo=akeraios%i;
        ypoloipo==1? putchar('1'):putchar('0');
        akeraios=akeraios/i;

    }
    return 0;
}






