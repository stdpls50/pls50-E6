/* 8.E. PLS50 (2016-17) GRAPTH ERGASIA E1 *
** GRIGORIADOU MARIA                      *
** THEMA 2: GEWMETRIKOI YPOLOGISMOI       */


/*Header Files*/
#include <stdio.h>
#include <math.h> //orizetai to arxeio epikefalidas math.h gia th xrhsh twn sunarthsewn sqrt() kai pow()

#define pi 3.141592 //orizetai h sta8era pi

/*Main Program*/
double perimetros_tetragwnou(double x); //orizetai h sunarthsh gia ton upologismo ths perimetrou tou tetragwnou
double perimetros_or8ogwniou(double x, double y); //orizetai h sunarthsh gia ton upologismo perimetrou tou or8ogwniou
double perimetros_trigwnou(double x, double y); //orizetai sunarthsh gia ton upologismo perimetrou tou trigwnou
double perimetros_kuklou(double r); //orizetai sunarthsh gia ton upologismo perimetrou tou kuklou


int main(void)
{
    char choice; //orizetai h metavliti choice gia to diavasma ths epiloghs tou xrhsth
    double sideA,sideB,aktina; //orizontai oi metavlites gia to diavasma twn diastasewn kai ths aktinas pou zhtountai apo to xrhsth

    do  //Emfanish tou menou epilogwn sthn o8oni tou xrhsth gia epilogh sxhmatos kai ektupwsh perimetrou
    {
        printf("Epele3e:\n");
        printf("0 gia e3odo\n");
        printf("1 gia tetragwno\n");
        printf("2 gia parallhlogrammo\n");
        printf("3 gia or8ogwnio trigwno\n");
        printf("4 gia kuklo\n");
        scanf(" %c",&choice);

        /*Analoga me thn epilogh tou sxhmatos, zhteitai apo to xrhsth na dwsei th/tis diastash/eis tou sxhmatos h thn aktina ston kuklo*
        **Sth sunexeia afou klh8ei ki ektelestei h antistoixh sunarthsh, emfanizetai h perimetros sthn o8onh tou xrhsth */
        if (choice=='1') //periptwsh tetragwnou
       {
           printf("Dwse to mhkos ths pleuras tou tetragwnou:\n");
           scanf("%lf",&sideA);
           printf("\nH perimetros tou tetragwnou me pleures %f einai %f.\n",sideA,perimetros_tetragwnou(sideA));

       }
       else if (choice=='2') //periptwsh parallilogrammou
       {
           printf("Dwse to mhkos kai to platos tou or8ogwniou:\n");
           scanf("%lf %lf",&sideA,&sideB);
           printf("H perimetros tou or8ogwniou me pleures %f kai %f einai %f.\n",sideA,sideB,perimetros_or8ogwniou(sideA,sideB));
       }
      else if (choice=='3') //periptwsh or8ogwniou trigwnou
       {
           printf("Dwse to mhkos twn 2 ka8etwn pleurwn tou or8ogwniou trigwnou:\n");
           scanf("%lf %lf",&sideA,&sideB);
           printf("H perimetros tou or8ogwniou trigwnou me ka8etes pleures %f kai %f einai %f.\n",sideA,sideB,perimetros_trigwnou(sideA,sideB));
       }
       else if(choice=='4') //periptwsh kuklou
       {
           printf("Dwse aktina kuklou:\n");
           scanf("%lf",&aktina);
           printf("H perimetros kuklou aktinas %f einai %f.\n",aktina,perimetros_kuklou(aktina));
       }
       printf("____________________________________\n");

    }while (choice!='0'); //h leitourgia tou programmatos epanalamvanetai wspou o xrhsths na epile3ei 0, dhl e3odo

    return 0;
}


double perimetros_tetragwnou(double x) //ekteleitai h sunarthsh upologismou perimetrou tetargwnou otan kaleitai
 {
     return (4*x);
 }

double perimetros_or8ogwniou(double x, double y) //ekteleitai h sunarthsh upologismou perimetrou or8ogwniou otan kaleitai
 {
     return (2*x+2*y);
 }

double perimetros_trigwnou(double x, double y)//ekteleitai h sunarthsh upologismou perimetrou or8ogwniou trigwnou otan kaleitai
 {
     double z;  //h  metavlhth z kataxwrizei thn upoteinousa tou trigwnou, pou einai aparaithth gia ton teliko upologismo ths perimetrou
     z=sqrt(pow(x,2)+pow(y,2)); //h upoteinousa upologizetai apo to pu8agoreio 8ewrhma
     return (x+y+z);
 }

double perimetros_kuklou(double r) //ekteleitai h sunarthsh upologismou perimetrou kuklou otan kaleitai
{
    return (2*pi*r);
}
